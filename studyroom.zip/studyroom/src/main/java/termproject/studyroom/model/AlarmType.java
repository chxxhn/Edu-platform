package termproject.studyroom.model;


public enum AlarmType {

    COMMENT,
    BOARD,
    REQUEST,
    MESSAGE,
    WARNING

}
