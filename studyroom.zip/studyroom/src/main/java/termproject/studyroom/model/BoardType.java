
package termproject.studyroom.model;

public enum BoardType {
    QUESTION_BOARD,
    SHARING_BOARD,
    LECTURE_REQUEST,
    COMMUNICATION_BOARD,
}
