package termproject.studyroom.controller.LectureSeqId;

public class LectureUserController {
}
