package termproject.studyroom.controller.Member;

public class MLectureListController {
}
