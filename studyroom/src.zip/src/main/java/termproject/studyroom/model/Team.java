package termproject.studyroom.model;


import lombok.Getter;
import lombok.Setter;

@Getter
public enum Team {

    TEAMLEADER,
    TEAMMEMBER

}
