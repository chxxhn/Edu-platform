package termproject.studyroom.model;


public enum Category {

    SHARING,
    OLDEXAM,
    LECTUREREQUEST

}
